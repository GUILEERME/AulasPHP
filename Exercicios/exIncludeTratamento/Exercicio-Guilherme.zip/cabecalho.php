<?php

$data = date('d/m/Y');
echo $data;

?>
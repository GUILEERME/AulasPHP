<?php

date_default_timezone_set("America/Sao_Paulo");
echo " Agora são " . date("H:i:s");

?>